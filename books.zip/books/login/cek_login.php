<?php 
session_start();
include '../koneksi.php';

$username = $_POST['username'];
$password = $_POST['password'];

$query = "select * from admin where username='$username' and password='$password'";
$query1 = "select * from pelanggan where email='$username' and password='$password'";

$data = mysqli_query($kon,$query);
$data1 = mysqli_query($kon,$query1);

$cek = mysqli_num_rows($data);
$cek1 = mysqli_num_rows($data1);
if($cek>0 || $cek1>0){
    $row = mysqli_fetch_array($data);
    $row1 = mysqli_fetch_array($data1);

    if($row){
        $_SESSION['username'] = $row['username'];
        $_SESSION['password'] = $row['password'];


        header("location:../admin/index.php");

    }else{
        $_SESSION['id_pelanggan'] = $row1['id_pelanggan'];
        $_SESSION['email'] = $row1['email'];
        $_SESSION['password'] = $row1['password'];
        $_SESSION['nama_pelanggan'] = $row1['nama_pelanggan'];
        

        header("location:../pelanggan/index.php");
    }

}else{
    header("location:login.php?pesan=gagal");
}
