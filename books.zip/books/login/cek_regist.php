<?php 
//Tambahkan Koneksi Databases
include '../koneksi.php';

//menerima data dari form
$nama_pelanggan= $_POST['nama_pelanggan'];
$alamat= $_POST['alamat'];
$kota= $_POST['kota'];
$provinsi = $_POST['provinsi'];
$kdpos= $_POST['kdpos'];
$tlpn= $_POST['tlpn'];
$fax= $_POST['fax'];
$email= $_POST['email'];
$password= $_POST['password'];

mysqli_query($kon, "insert into pelanggan values (null,'$nama_pelanggan','$alamat','$kota','$provinsi',$kdpos,$tlpn,$fax,'$email','$password')");
header("location:login.php");
?>