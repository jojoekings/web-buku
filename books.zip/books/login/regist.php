<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
    <div class="container mt-5">    
        <div class="card-header">
            <h1>Silahkan Regristrasi Akun Anda</h1>
            <div class="card-body">
                <form action="cek_regist.php" class="row g-3" method="post">
                    <div class="col-6">
                        <label for="" class="form-label">Nama</label>
                        <input type="text" class="form-control" name="nama_pelanggan">
                    </div>
                    <div class="col-6">
                        <label for="" class="form-label">alamat</label>
                        <input type="text" class="form-control" name="alamat">
                    </div>
                    <div class="col-6">
                        <label for="" class="form-label">kota</label>
                        <input type="text" class="form-control" name="kota">
                    </div>
                    <div class="col-md-6">
                        <label for="" class="form-label">Provinsi</label>
                        <select name="provinsi" id="provinsi" class="form-select">
                            <option value="Nanggroe Aceh Darussalam">Nanggroe Aceh Darussalam</option>
                            <option value="Sumatera Utara">Sumatera Utara</opt1on>
                            <option value="Sumatera Selatan">Sumatera Selatan</option>
                            <option value="Sumatera Barat">Sumatera Barat</option>
                            <option value="Bengkulu">Bengkulu</option>
                            <option value="Riau">Riau</option>
                            <option value="Kepulauan Riau">Kepulauan Riau</option>
                            <option value="Jambi">Jambi</option>
                            <option value="Lampung">Lampung</option>
                            <option value="Bangka Belitung">Bangka Belitung</option>
                            <option value="Kalimantan Barat">Kalimantan Barat</option>
                            <option value="Kalimantan Timur">Kalimantan Timur</option>
                            <option value="Kalimantan Selatan">Kalimantan Selatan</opt1on>
                            <option value="Kalimantan Tengah">Kalimantan Tengah</option>
                            <option value="Kalimantan Utara">Kalimantan Utara</option>
                            <option value="Banten">Banten</option>
                            <option value="Dki Jakarata">Dki Jakarata</option>
                            <option value="Jawa Barat">Jawa Barat</option>
                            <option value="Jawa Tengah">Jawa Tengah</option>
                            <option value="Daerah Istimewa Yogyakarta">Daerah Istimewa Yogyakarta</option>
                            <option value="Jawa Timur">Jawa Timur</option>
                            <option value="Bali">Bali</option>
                            <option value="Nusa Tenggara Timur">Nusa Tenggara Timur</option>
                            <option value="Nusa Tenggara Barat">Nusa Tenggara Barat</opt1on>
                            <option value="Gorontalo">Gorontalo</option>
                            <option value="Sulawesi Barat">Sulawesi Barat</option>
                            <option value="Sulawesi Tengah">Sulawesi Tengah</option>
                            <option value="Sulawesi Utara">Sulawesi Utara</option>
                            <option value="Sulawesi Tenggara">Sulawesi Tenggara</option>
                            <option value="Sulawesi Selatan">Sulawesi Selatan</option>
                            <option value="Maluku Utara">Maluku Utara</option>
                            <option value="Maluku">Maluku</option>
                            <option value="Papua Barat">Papua Barat</option>
                            <option value="Papua">Papua</option>
                            <option value="Papua Tengah">Papua Tengah</option>
                            <option value="Papua Pegunungan">Papua Pegunungan</option>
                            <option value="Papua Selatan">Papua Selatan</option>
                            <option value="Papua Barat Daya">Papua Barat Daya</option>
                        </select>
                    </div>
                    <div class="col-6">
                        <label for="" class="form-label">kode pos</label>
                        <input type="text" class="form-control" name="kdpos">
                    </div>
                    <div class="col-6">
                        <label for="" class="form-label">tlpn</label>
                        <input type="text" class="form-control" name="tlpn">
                    </div>
                    <div class="col-6">
                        <label for="" class="form-label">fax</label>
                        <input type="text" class="form-control" name="fax">
                    </div>
                    <div class="col-6">
                        <label for="" class="form-label">email</label>
                        <input type="text" class="form-control" name="email">
                    </div>
                    <div class="col-6">
                        <label for="" class="form-label">Password</label>
                        <input type="password" class="form-control" name="password">
                    </div>
                    <input type="submit" value="submit">
                </form>
            </div>
        </div>
    </div>
</body>

</html>