<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <title>Home | BOOKSTORE</title>
</head>

<body>

    <div class="bg">
        <nav id='menu'>
            <ul>
                <li><a href='dashboard.php'>BOOK</a></li>
                <li><a href='index.php'>Products</a>
                    <ul class='sub-menus'>
                        <li><a href='http://'>Products 1</a></li>
                        <li><a href='http://'>Products 2</a></li>
                        <li><a href='http://'>Products 3</a></li>
                        <li><a href='http://'>Products 4</a></li>
                    </ul>
                </li>
                <li><a href='http://'>About</a></li>
                <li><a href='admin.php'>Contact Us</a></li>
                <li><a href='login/login.php'>Login</a></li>
            </ul>
        </nav>
    </div>
    <br>
    <div class="f">
        <center>
            <h2>Trending topic</h2>
        </center>
    </div>
    <div class="hero">
        <?php
        include 'koneksi.php';
        $query = 'select * from buku';
        $data = mysqli_query($kon, $query);
        $no = 1;
        while ($row = mysqli_fetch_array($data)) {
        ?>
            <div class="imgg">
                <div class="foto">
                    <img class="d-block w-100" src="admin/foto/<?php echo $row['foto']; ?>" height="300">
                </div>
                <p><?= $row['judul'] ?></p>
            </div>
        <?php $no++;
        } ?>
    </div>
</body>

</html>