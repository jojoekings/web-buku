<?php
session_start();
include '../koneksi.php';
$id_buku = $_GET['id_buku'] ;
$data = mysqli_query($kon,"select * from buku where id_buku = '$id_buku'");
$row = mysqli_fetch_array($data);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
            <div class="container-fluid">
                <div class="collapse navbar-collapse">
                    <ul class="navbar-nav me-auto mb-2 mb-md-0">
                        <li class="nav-item">
                            <a href="index.php" class="nav-link">Home</a>
                        </li>
                        <li class="nav-item">
                            <a href="pesan.php" class="nav-link">Pesan</a>
                        </li>
                        <li class="nav-item">
                            <a href="logout.php" class="nav-link">logout</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <main>

    <div class="album py-5 bg-light">
        <div class="container mt-5">
            <div class="card">
                <div class="card-header">
                    <h3>Judul Buku <?= $row['judul']?></h3>
                </div>
                <div class="card-body">
                    <center><img src="img/<?= $row['foto']?>" alt=""width="20%" height="400" alt=""></center>
                    <form action="aksipesan.php" method="post">
                        <input type="hidden" name="id_buku" value="<?= $row['id_buku'] ?>">
                        <label for="">Jumlah</label>
                        <input type="number" name="jumlah_barang" id="" onchange="calculateAmount(this.value)" class="form-control" required>
                        <div class="row">
                            <div class="col-8">
                                <label for="">Harga</label>
                                    <input type="number" name="harga" id="harga" value="<?= $row['harga'] ?>" class="form-control" disabled >
                            </div>
                            <div class="col-4">
                            <label for="">diskon</label>
                            <input type="number" name="diskon" id="diskon" value="<?= $row['diskon'] ?>" class="form-control" disabled >
                            </div>
                        </div>
                        <label for="">SubTotal</label>
                        <input type="text" name="subtotal" id="subtotal"  class="form-control" readonly >

                        <input type="submit" value="Pesan" class="btn btn-primary">
                    </form>
                </div>
            </div>
        </div>
      
    </div>
    
    </main>
    <script type ="text/javascript">  
            function calculateAmount(val) { 
                var harga = document.getElementById('harga').value;
                var diskon = document.getElementById('diskon').value; 
                var hargadiskon = (diskon/100)*harga;
                var hargabayar = harga-hargadiskon;
                var tot_price = val * hargabayar;  
                var divobj = document.getElementById('subtotal');  
                divobj.value = tot_price;  
            }  
        </script>  
    <script src="bs/js/bootstrap.bundle.min.js"></script>
</body>
</html>