<?php
session_start();
include '../koneksi.php';

$id_buku = $_POST['id_buku'];
$jumlah_barang = $_POST['jumlah_barang'];
$subtotal = $_POST['subtotal'];
$pelanggan = $_SESSION['id_pelanggan'];
$tgl_sekarang = date("Y-m-d");
$status_pesan = "belum bayar";
$data = mysqli_query($kon,"insert into dpesan values(null,'$id_buku','$jumlah_barang','$subtotal')");
$data1 = mysqli_query($kon,"insert into pesan values(null,'$pelanggan','$tgl_sekarang','$status_pesan')");

header("location:pesan.php");

?>