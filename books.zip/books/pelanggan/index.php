<?php
include '../koneksi.php';
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
            <div class="container-fluid">
                <div class="collapse navbar-collapse">
                    <ul class="navbar-nav me-auto mb-2 mb-md-0">
                        <li class="nav-item">
                            <a href="index.php" class="nav-link">Home</a>
                        </li>
                        <li>
                            <a href="pesan.php" class="nav-link">Pesan</a>
                        </li>
                        <li>
                            <a href="logout.php" class="nav-link">Logout</a>
                        </li>
                    </ul>
                </div>
            </div>
            <a href="index.php" class="navbar-brand">Synthics Store</a>
        </nav>
    </header>

    <main>
        <div id="myCarousel" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="0" class="active"
                    aria-current="true" aria-label="Slide 1"></button>
            </div>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg"
                        aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false" src="foto/sampul">
                        <rect width="100%" height="100%" fill="" />
                    </svg>

                    <div class="container">
                        <div class="carousel-caption text-start">
                            <h1>Synthics Store.</h1>
                            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Repellat veritatis sunt modi,
                                recusandae nihil facilis illo, esse dolore dolor consectetur alias qui iusto quas quod
                                id voluptate, rem laboriosam. Nesciunt.</p>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg"
                        aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false">
                        <rect width="100%" height="100%" fill="#777" />
                    </svg>

                </div>

            </div>

            <div class="album py-5 bg-light">
                <div class="container">
                    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-4 g-4">
                        <?php
                        $data = mysqli_query($kon, "SELECT * FROM buku left join kategori on buku.id_kategori = kategori.id_kategori left join penerbit on buku.id_penerbit = penerbit.id_penerbit left join pengarang on buku.id_pengarang = pengarang.id_pengarang order by id_buku desc limit 8");
                        while ($row = mysqli_fetch_array($data)) {
                            ?>
                            <div class="col">
                                <div class="card shadow-sm">
                                    <img src="img/<?= $row['foto'] ?>" width="100%" height="400" alt="">

                                    <div class="card-body">
                                        <h4 style="overflow: hidden; white-space: nowrap; text-overflow: ellipsis;"
                                            title="<?= $row['judul'] ?>">
                                            <?= $row['judul'] ?>
                                        </h4>
                                        <p class="card-text">
                                            <?= $row['kategori'] ?>
                                        </p>
                                        <h5>
                                            <?= $row['penerbit'] ?>
                                        </h5>

                                        <div class="d-flex justify-content-between align-items-center">
                                            <div class="btn-group">
                                            </div>
                                            <small class="text-muted">Rp.
                                                <?= number_format($row['harga'], 2, ',', '.') ?>
                                            </small>
                                        </div>
                                        <a href="pesanbuku.php?id_buku=<?= $row['id_buku'] ?>" class="btn btn-info">Beli</a>

                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
    </main>

    <script type ="text/javascript">  
            function calculateAmount(val) { 
                var harga = document.getElementById('harga').value;
                var diskon = document.getElementById('diskon').value; 
                var hargadiskon = (diskon/100)*harga;
                var hargabayar = harga-hargadiskon;
                var tot_price = val * hargabayar;  
                var divobj = document.getElementById('subtotal');  
                divobj.value = tot_price;  
            }  
        </script>  
    <script src="bs/js/bootstrap.bundle.min.js"></script>
</body>

</html>