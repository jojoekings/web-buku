<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>

<body>
  <?php
  session_start();
  include 'navbar/navbar.php'
  ?>
  <div class="content-wrapper">

    <div class="content">
      <div class="container">
        <div class="col-md-12">
          <div class="card card-outline card-info">
            <div class="card-body">
              <div class="row">

                <div class="col-lg-3">

                  <!-- small card -->
                  <div class="small-box bg-info">
                    <h3>Data kategori</h3>
                    <div class="inner">
                      <?php
                      include '../koneksi.php';
                      $no = 1;
                      $data = mysqli_query($kon, "select * from kategori");
                      $jumlah_kategori = mysqli_num_rows($data);
                      ?>
                      <h3> <?php echo $jumlah_kategori; ?></h3>
                    </div>
                    <div class="icon">
                      <i class="fas fa-user"></i>
                    </div>
                    <a href="kategori.php" class="small-box-footer">
                      Clik Here! <i class="fas fa-arrow-circle-right"></i>
                    </a>
                  </div>
                </div>

                <div class="col-lg-3 col-6">

                  <!-- small card -->
                  <div class="small-box bg-info">
                    <h3>Data penerbit</h3>
                    <div class="inner">
                      <?php
                      include '../koneksi.php';
                      $no = 1;
                      $data = mysqli_query($kon, "select * from penerbit");
                      $jumlah_penerbit = mysqli_num_rows($data);
                      ?>
                      <h3> <?php echo $jumlah_penerbit; ?></h3>
                    </div>
                    <div class="icon">
                      <i class="fas fa-user"></i>
                    </div>
                    <a href="penerbit.php" class="small-box-footer">
                      Clik Here! <i class="fas fa-arrow-circle-right"></i>
                    </a>
                  </div>
                </div>

                <div class="col-lg-3 col-6">
                  <!-- small card -->
                  <div class="small-box bg-info">
                    <h3>Data pengarang</h3>
                    <div class="inner">
                      <?php
                      include '../koneksi.php';
                      $no = 1;
                      $data = mysqli_query($kon, "select * from pengarang");
                      $jumlah_pengarang = mysqli_num_rows($data);
                      ?>
                      <h3> <?php echo $jumlah_pengarang; ?></h3>
                    </div>
                    <div class="icon">
                      <i class="fas fa-user"></i>
                    </div>
                    <a href="pengarang.php" class="small-box-footer">
                      Clik Here! <i class="fas fa-arrow-circle-right"></i>
                    </a>
                  </div>
                </div>

                <div class="col-lg-3 col-6">

                  <!-- small card -->
                  <div class="small-box bg-info">
                    <h3>Data Pesanan</h3>
                    <div class="inner">
                      <?php
                      include '../koneksi.php';
                      $no = 1;
                      $data = mysqli_query($kon, "select * from kirim");
                      $jumlah_kirim = mysqli_num_rows($data);
                      ?>
                      <h3> <?php echo $jumlah_kirim; ?></h3>
                    </div>
                    <div class="icon">
                      <i class="fas fa-user"></i>
                    </div>
                    <a href="Kirim.php" class="small-box-footer">
                      Clik Here! <i class="fas fa-arrow-circle-right"></i>
                    </a>
                  </div>
                </div>

                <div class="col-lg-3 mt-3">

                  <!-- small card -->
                  <div class="small-box bg-info">
                    <h3>Data Buku</h3>
                    <div class="inner">
                      <?php
                      include '../koneksi.php';
                      $no = 1;
                      $data = mysqli_query($kon, "select * from buku");
                      $jumlah_buku = mysqli_num_rows($data);
                      ?>
                      <h3> <?php echo $jumlah_buku; ?></h3>
                    </div>
                    <div class="icon">
                      <i class="fas fa-user"></i>
                    </div>
                    <a href="buku.php" class="small-box-footer">
                      Clik Here! <i class="fas fa-arrow-circle-right"></i>
                    </a>
                  </div>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
</body>

</html>