<?php
session_start();
include '../koneksi.php';
include 'navbar/navbar.php';

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

</head>

<body>
    <div class="container mt-5">
        <a href="tambah/tambah_buku.php"><button type="button" class="btn btn-dark">Tambah penerbit</button></a>
        <table class="mt-4 table">
            <thead>
                <tr class="table-dark">
                    <th>No</th>
                    <th>Gambar</th>
                    <th>Kategori</th>
                    <th>Pengarang</th>
                    <th>Penerbit</th>
                    <th>Judul</th>
                    <th>Harga</th>
                    <th>Detail</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $query = 'select * from buku join kategori on buku.id_kategori = kategori.id_kategori join pengarang on buku.id_pengarang = pengarang.id_pengarang join penerbit on buku.id_penerbit = penerbit.id_penerbit';
                $data = mysqli_query($kon, $query);
                $no = 1;
                while ($row = mysqli_fetch_array($data)) {
                ?>
                    <tr>
                        <td><?= $no ?></td>
                        <td><img src="foto/<?= $row['foto'] ?>" alt="" width="100"><?= $row['foto'] ?></td>
                        <td><?= $row['kategori'] ?></td>
                        <td><?= $row['pengarang'] ?></td>
                        <td><?= $row['penerbit'] ?></td>
                        <td><?= $row['judul'] ?></td>
                        <td><?= number_format($row['harga'], 2, ",", ".") ?></td>
                        <td><a href="print.php?id_pembayaran=<?= $d['id_pembayaran'] ?>" class="btn btn-info">Detail</a></td>
                        <td><a href="edit/edit_buku.php?id_buku=<?= $row['id_buku'] ?>" class="btn btn btn-warning">Edit</a>
                        <a href="aksi/dlt_buku.php?id_buku=<?= $row['id_buku'] ?>" class="btn btn btn-danger">Hapus</a></td>
                    </tr>
                <?php $no++;
                } ?>
            </tbody>
        </table>
    </div>
</body>

</html>