<?php
session_start();
include '../koneksi.php';
include 'navbar/navbar.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <div class="container mt-5">
        <div class="mt-5 pt-5">
            <h1>Kategori</h1>
        </div>
        <table class="table table-striped mt-5">
            <tr>
                <td>No</td>
                <td>judul</td>
                <td>Tanggal pesan</td>
                <td>tanggal kirim</td>
                <td>status pesan</td>
                <td>keterangan</td>
                <td>subtotal</td>
                <td>Aksi</td>
            </tr>
            <?php
            $query = "select * from pesan join kirim on kirim.id_pesan = pesan.id_pesan join dpesan on dpesan.id_pesan = pesan.id_pesan join buku on buku.id_buku = dpesan.id_buku where pesan.status_pesan = 'sudah bayar' or kirim.keterangan='dikirim'";
            $data = mysqli_query($kon, $query);
            $no = 1;
            while ($row = mysqli_fetch_array($data)) {
            ?>
                <tr>
                    <td><?= $no ?></td>
                    <td><?= $row['judul'] ?></td>
                    <td><?= $row['tgl_pesan'] ?></td>
                    <td><?= $row['tgl_kirim'] ?></td>
                    <td><?= $row['status_pesan'] ?></td>
                    <td><?= $row['keterangan'] ?></td>
                    <td><?= $row['subtotal'] ?></td>
                    <td>
                        <a href="aksikirim.php?id_kirim=<?= $row['id_kirim'] ?>&id_pesan=<?= $row['id_pesan'] ?>" class="btn btn-outline-warning">Kirim</a>
                    </td>
                </tr>
            <?php $no++;
            } ?>
        </table>

</body>

</html>