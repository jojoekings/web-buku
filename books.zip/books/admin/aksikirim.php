<?php
session_start();
include '../koneksi.php';
$id_kirim = $_GET['id_kirim'];
$id_pesan = $_GET['id_pesan'];

$tgl_sekarang = date("Y-m-d");
$data = mysqli_query($kon,"update kirim set tgl_kirim = '$tgl_sekarang', keterangan='dikirim' where id_kirim = '$id_kirim'");
$data1 = mysqli_query($kon,"update pesan set status_pesan = 'Sudah Dikirim' where id_pesan = '$id_pesan'");

header("location:kirim.php");

?>  