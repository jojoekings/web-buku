<?php 
    include '../../koneksi.php';

    $penerbit = $_POST ['penerbit'];
    $id_penerbit = $_POST ['id_penerbit'];

    $query = "update penerbit set penerbit ='$penerbit' where id_penerbit =$id_penerbit";
    $data = mysqli_query($kon, $query);
    header("location:../penerbit.php");
?>