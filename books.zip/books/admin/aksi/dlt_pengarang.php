<?php
include '../../koneksi.php';
$id_pengarang = $_GET['id_pengarang'];
// $_Get untuk mengambil id/variabel , yang akan ditampilkan url
$query = "delete from pengarang where id_pengarang=$id_pengarang";
$data = mysqli_query($kon,$query);
header("location:../pengarang.php");
?>