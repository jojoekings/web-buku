<?php 
    include '../../koneksi.php';

    $kategori = $_POST ['kategori'];
    $id_kategori = $_POST ['id_kategori'];

    $query = "update kategori set kategori ='$kategori' where id_kategori =$id_kategori";
    $data = mysqli_query($kon, $query);
    header("location:../kategori.php");
?>