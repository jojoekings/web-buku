<?php 
    include '../../koneksi.php';

    $pengarang = $_POST ['pengarang'];
    $id_pengarang = $_POST ['id_pengarang'];

    $query = "update pengarang set pengarang ='$pengarang' where id_pengarang =$id_pengarang";
    $data = mysqli_query($kon, $query);
    header("location:../pengarang.php");
?>