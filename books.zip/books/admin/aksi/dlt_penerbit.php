<?php
include '../../koneksi.php';
$id_penerbit = $_GET['id_penerbit'];
// $_Get untuk mengambil id/variabel , yang akan ditampilkan url
$query = "delete from penerbit where id_penerbit=$id_penerbit";
$data = mysqli_query($kon,$query);
header("location:../penerbit.php");
?>