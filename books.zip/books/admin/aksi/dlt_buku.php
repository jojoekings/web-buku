<?php
include '../../koneksi.php';
$id_buku = $_GET['id_buku'];
// $_Get untuk mengambil id/variabel , yang akan ditampilkan url
$query = "delete from buku where id_buku=$id_buku";
$data = mysqli_query($kon,$query);
header("location:../buku.php");
?>