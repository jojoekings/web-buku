<?php
include '../../koneksi.php';

$id_buku = $_POST['id_buku'];
$id_kategori = $_POST['id_kategori'];
$id_pengarang = $_POST['id_pengarang'];
$id_penerbit = $_POST['id_penerbit'];
$judul = $_POST['judul'];
$harga = $_POST['harga'];
$tahun  = $_POST['tahun'];
$isbn = $_POST['isbn'];
$diskon = $_POST['diskon'];
$ukuran = $_POST['ukuran'];
$halaman = $_POST['halaman'];
$sinopsis = $_POST['sinopsis'];
$foto = $_FILES['foto']['name'];
$tempname = $_FILES['foto']['tmp_name'];
$folder = "../foto/" . $foto;

if($foto != ''){
$query = "update buku set id_kategori = '$id_kategori', id_pengarang = '$id_pengarang', id_penerbit = '$id_penerbit', judul = '$judul', harga = '$harga', tahun = '$tahun', 
isbn = '$isbn', diskon = '$diskon', ukuran = '$ukuran', halaman = '$halaman', sinopsis = '$sinopsis' , foto = '$foto' where id_buku = '$id_buku'";
$data = mysqli_query($kon,$query);

if(move_uploaded_file($tempname,$folder)){
    header("location:../buku.php");
}

}else{
    $query = "update buku set id_kategori = '$id_kategori', id_pengarang = '$id_pengarang',  id_penerbit = '$id_penerbit', judul = '$judul', harga = '$harga', tahun = '$tahun', 
    isbn = '$isbn', diskon = '$diskon', ukuran = '$ukuran', halaman = '$halaman', sinopsis = '$sinopsis' where id_buku = '$id_buku'";
    $data = mysqli_query($kon,$query);

    header("location:../buku.php");

}

header("location:../buku.php");

?>
