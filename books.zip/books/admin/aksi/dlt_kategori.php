<?php
include '../../koneksi.php';
$id_kategori = $_GET['id_kategori'];
// $_Get untuk mengambil id/variabel , yang akan ditampilkan url
$query = "delete from kategori where id_kategori=$id_kategori";
$data = mysqli_query($kon,$query);
header("location:../kategori.php");
?>