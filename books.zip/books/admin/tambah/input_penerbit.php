<?php
include '../../koneksi.php';

$penerbit =$_POST['penerbit'];

mysqli_query($kon,"insert into penerbit values(null,'$penerbit')");
header("location:../penerbit.php");
?>