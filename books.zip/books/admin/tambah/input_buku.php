<?php
include '../../koneksi.php';

$id_kategori =$_POST['id_kategori'];
$id_pengarang =$_POST['id_pengarang'];
$id_penerbit =$_POST['id_penerbit'];
$judul =$_POST['judul'];
$tahun =$_POST['tahun'];
$isbn =$_POST['isbn'];
$harga =$_POST['harga'];
$diskon =$_POST['diskon'];
$ukuran =$_POST['ukuran'];
$halaman =$_POST['halaman'];
$sinopsis =$_POST['sinopsis'];
$foto = $_FILES['foto']['name'];
$tempname = $_FILES['foto']['tmp_name'];
$folder = "../foto/" . $foto;

$query = "insert into buku values(null,'$id_kategori','$id_pengarang','$id_penerbit','$judul','$tahun','$isbn','$harga','$diskon','$ukuran','$halaman','$sinopsis','$foto')";
$data = mysqli_query($kon,$query);

if(move_uploaded_file($tempname,$folder)){
    header("location:../buku.php");
}
?>