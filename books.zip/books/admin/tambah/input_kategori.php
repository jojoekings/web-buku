<?php
include '../../koneksi.php';

$kategori =$_POST['kategori'];

mysqli_query($kon,"insert into kategori values(null,'$kategori')");
header("location:../kategori.php");
?>