<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
    <div class="container mt-5">
        <div class="card">
            <div class="card-header">
                Featured
            </div>
            <div class="card-body">
                <form class="row g-3" action="input_buku.php" method="post" enctype="multipart/form-data">
                    <div class="col-md-6">
                        <label for="" class="form-label">Kategori</label>
                        <select name="id_kategori" id="id_kategori" class="form-select">
                            <?php
                            include '../../koneksi.php';
                            $data = mysqli_query($kon, "select * from kategori");
                            while ($d = mysqli_fetch_array($data)) {
                            ?>
                                <option value="<?= $d['id_kategori'] ?>"><?= $d['kategori'] ?></option>
                            <?php
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="" class="form-label">Pengarang</label>
                        <select name="id_pengarang" id="id_pengarang" class="form-select">
                            <?php
                            include '../../koneksi.php';
                            $data = mysqli_query($kon, "select * from pengarang");
                            while ($d = mysqli_fetch_array($data)) {
                            ?>
                                <option value="<?= $d['id_pengarang'] ?>"><?= $d['pengarang'] ?></option>
                            <?php
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="" class="form-label">Penerbit</label>
                        <select name="id_penerbit" id="id_penerbit" class="form-select">
                            <?php
                            include '../../koneksi.php';
                            $data = mysqli_query($kon, "select * from penerbit");
                            while ($d = mysqli_fetch_array($data)) {
                            ?>
                                <option value="<?= $d['id_penerbit'] ?>"><?= $d['penerbit'] ?></option>
                            <?php
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="" class="form-label">judul</label>
                        <input type="text" name="judul" class="form-control">
                    </div>
                    <div class="col-md-6">
                        <label for="" class="form-label">tahun</label>
                        <input type="text" name="tahun" class="form-control">
                    </div>
                    <div class="col-md-6">
                        <label for="" class="form-label">isbn</label>
                        <input type="text" name="isbn" class="form-control">
                    </div>
                    <div class="col-md-6">
                        <label for="" class="form-label">harga</label>
                        <input type="text" name="harga" class="form-control">
                    </div>
                    <div class="col-md-6">
                        <label for="" class="form-label">Diskon</label>
                        <input type="text" name="diskon" class="form-control">
                    </div>
                    <div class="col-md-6">
                        <label for="" class="form-label">ukuran</label>
                        <input type="text" name="ukuran" class="form-control">
                    </div>
                    <div class="col-md-6">
                        <label for="" class="form-label">halaman</label>
                        <input type="text" name="halaman" class="form-control">
                    </div>
                    <div class="col-md-6">
                        <label for="" class="form-label">sinopsis</label>
                        <input type="text" name="sinopsis" class="form-control">
                    </div>
                    <div class="col-md-6">
                        <label for="" class="form-label">Gambar</label>
                        <input type="file" name="foto" class="form-control">
                    </div>
                    <input type="submit" value="simpan">
                </form>
            </div>
        </div>
    </div>
</body>

</html>