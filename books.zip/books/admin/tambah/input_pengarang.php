<?php
include '../../koneksi.php';

$pengarang =$_POST['pengarang'];

mysqli_query($kon,"insert into pengarang values(null,'$pengarang')");
header("location:../pengarang.php");
?>