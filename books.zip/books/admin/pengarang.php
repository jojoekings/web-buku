<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
    <?php
    session_start();
    include 'navbar/navbar.php'
    ?>
    <div class="container mt-5">
        <a href="tambah/tambah_kategori.php"><button type="button" class="btn btn-dark">Tambah Pengarang</button></a>
        <table class="mt-4 table">
            <thead>
                <tr class="table-dark">
                    <th scope="col">No</th>
                    <th scope="col">pengarang</th>
                    <th scope="col">aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include '../koneksi.php';
                $query = 'select * from pengarang';
                $data = mysqli_query($kon, $query);
                $no = 1;
                while ($row = mysqli_fetch_array($data)) {
                ?>
                    <tr>
                        <td><?= $no ?></td>
                        <td><?= $row['pengarang'] ?></td>
                        <td>
                            <a href="edit/edit_pengarang.php?id_pengarang=<?= $row['id_pengarang']; ?>" class="btn btn btn-warning">Edit</a>
                            <a href="aksi/dlt_pengarang.php?id_pengarang=<?= $row['id_pengarang']; ?>" class="btn btn btn-danger">Hapus</a>
                        </td>
                    </tr>
                <?php $no++;
                } ?>
            </tbody>
        </table>
    </div>
</body>

</html>