<?php
session_start();
include 'navbar.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
<header>

    <div class="container mt-5">
        <h2 class="pt-5">Data Pemesan Buku</h2>
    <table class="table table-striped pt-5">
        <tr>
            <td>no</td>
            <td>judul</td>
            <td>jumlah</td>
            <td>subtotal</td>
            <td>status</td>
            <td>Aksi</td>
        </tr>
        <?php
        include '../koneksi.php';
        $query = "select * from dpesan join pesan on pesan.id_pesan = dpesan.id_pesan join buku on buku.id_buku = dpesan.id_pesan";
        $data = mysqli_query($kon,$query);
        $no = 1;
         while ($row = mysqli_fetch_array($data)) {
        ?>
        <tr>
            <td><?= $no ?></td>
            <td><?= $row['judul']?></td>    
            <td><?= $row['jumlah_barang']?></td>
            <td><?= $row['subtotal']?></td>
            <td><?= $row['status_pesan']?></td>
            <td>
            <?php
                if($row['status_pesan'] == 'belum bayar'){
            ?>
            <a href="bayar.php?id=<?= $row['id_pesan']?>" class="btn btn-info">Bayar</a>
            <?php
                }else{
            ?>
            <a href="bayar.php?id=<?= $row['id_pesan']?>" class="btn btn-info disabled">Sudah Bayar</a>

            <?php 
                }
            ?>
            </td>
        </tr>
        <?php $no++ ; } ?>
    </table>
    </div> 
    
</body>
</html>