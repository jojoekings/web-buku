<?php
include '../koneksi.php';

$id_pelanggan = $_POST['id_pelanggan'];
$tgl_pesan = $_POST['tgl_pesan'];
$status_pesan = $_POST['status_pesan'];

$query = "insert into tb_pesan values(null, '$id_pelanggan','$tgl_pesan','$status_pesan')";
$data = mysqli_query($koneksi,$query);

header('location:pesan.php');
?>