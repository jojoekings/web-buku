<?php
session_start();
include '../koneksi.php';

$id_pesan = $_POST['id_pesan'];
$bank = $_POST['bank'];
$bukti_bayar = $_POST['jumlah_bayar'];
$tgl_sekarang = date("Y-m-d");
$keterangan = "Menunggu Pengiriman";
$data = mysqli_query($koneksi,"insert into tb_bayar values(null,'$id_pesan','$tgl_sekarang','$bank','$bukti_bayar')");
$data1 = mysqli_query($koneksi,"insert into tb_kirim values(null,'$id_pesan',null,'$keterangan')");
$data2 = mysqli_query($koneksi,"update tb_pesan set status_pesan='sudah bayar' where id_pesan='$id_pesan'");


header("location:pesan.php");

?>