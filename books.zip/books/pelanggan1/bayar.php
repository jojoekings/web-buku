<?php
session_start();
include '../koneksi.php';
$id_pesan = $_GET['id_pesan'] ;
$data = mysqli_query($kon,"select * from pesan where id_pesan = '$id_pesan'");
$row = mysqli_fetch_array($data);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
            <div class="container-fluid">
                <div class="collapse navbar-collapse">
                    <ul class="navbar-nav me-auto mb-2 mb-md-0">
                        <li class="nav-item">
                            <a href="index.php" class="nav-link">Home</a>
                        </li>
                        <li class="nav-item">
                            <a href="pesan.php" class="nav-link">Pesan</a>
                        </li>
                        <li class="nav-item">
                            <a href="logout.php" class="nav-link">logout</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <main>

    <div class="album py-5 bg-light">
        <div class="container mt-5">
            <div class="card">
                <div class="card-header">
                    <h3>Bayar Buku</h3>
                </div>
                <div class="card-body">
                    <form action="aksibayar.php" method="post">
                        <input type="text" name="id_pesan" value="<?= $row['id_pesan'] ?>">
                       
                        <label for="">Total Harus Dibayar</label>
                        <input type="text" name="subtotal" id="subtotal" value="<?= $row['subtotal'] ?>"  class="form-control" disabled >
                        <label for="">Bank</label>
                        <input type="text" name="bank" id="bank" class="form-control" >
                        <label for="">jumlah_bayar</label>
                        <input type="text" name="jumlah_bayar" id="jumlah_bayar" class="form-control" >

                        <input type="submit" value="Pesan" class="btn btn-primary">
                    </form>
                </div>
            </div>
        </div>
      
    </div>
    
    </main>
    <script type ="text/javascript">  
            function calculateAmount(val) { 
                var harga = document.getElementById('harga').value;
                var diskon = document.getElementById('diskon').value; 
                var hargadiskon = (diskon/100)*harga;
                var hargabayar = harga-hargadiskon;
                var tot_price = val * hargabayar;  
                var divobj = document.getElementById('subtotal');  
                divobj.value = tot_price;  
            }  
        </script>  
    <script src="bs/js/bootstrap.bundle.min.js"></script>
</body>
</html>