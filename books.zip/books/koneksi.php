<?php
$kon = mysqli_connect('localhost','root','','db_books') or die ('koneksi gagal');
?>