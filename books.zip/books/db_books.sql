-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 08, 2023 at 10:55 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_books`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_users` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_users`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `bayar`
--

CREATE TABLE `bayar` (
  `id_bayar` int(11) NOT NULL,
  `id_pesan` int(11) NOT NULL,
  `tgl_bayar` date DEFAULT NULL,
  `bank` varchar(30) NOT NULL,
  `bukti_bayar` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bayar`
--

INSERT INTO `bayar` (`id_bayar`, `id_pesan`, `tgl_bayar`, `bank`, `bukti_bayar`) VALUES
(1, 11, '2023-10-20', 'bca', '120000'),
(2, 20, '2023-10-23', 'BCA', '9'),
(3, 21, '2023-10-23', 'BCA', '300000');

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE `buku` (
  `id_buku` int(11) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  `id_pengarang` int(11) NOT NULL,
  `id_penerbit` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `tahun` year(4) NOT NULL,
  `isbn` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `diskon` varchar(30) NOT NULL,
  `ukuran` int(11) NOT NULL,
  `halaman` int(11) NOT NULL,
  `sinopsis` varchar(30) NOT NULL,
  `foto` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`id_buku`, `id_kategori`, `id_pengarang`, `id_penerbit`, `judul`, `tahun`, `isbn`, `harga`, `diskon`, `ukuran`, `halaman`, `sinopsis`, `foto`) VALUES
(2, 1, 1, 1, '5', 2001, 1, 2, '2', 2, 0, '2', 'eren.jpeg'),
(3, 1, 1, 1, '1', 2001, 1, 1, '1', 1, 11, '1', '1.jpg'),
(23, 1, 1, 1, 'One piece', 2023, 12213, 10, '10', 10, 100, 'comik', 'onepice.jpeg'),
(25, 1, 1, 1, 'zz', 0000, 0, 200000, '50', 0, 0, 'z', 'ariety.jpeg'),
(31, 1, 1, 1, 'Ponyo', 2022, 2131231, 100000, '25', 50, 250, 'komik', 'ponyo.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `dpesan`
--

CREATE TABLE `dpesan` (
  `id_pesan` int(11) NOT NULL,
  `id_buku` int(11) NOT NULL,
  `jumlah_barang` int(11) NOT NULL,
  `subtotal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dpesan`
--

INSERT INTO `dpesan` (`id_pesan`, `id_buku`, `jumlah_barang`, `subtotal`) VALUES
(11, 31, 1, 75000),
(12, 31, 1, 75000),
(13, 31, 1, 75000),
(14, 31, 2, 150000),
(15, 31, 1, 75000),
(16, 31, 1, 75000),
(17, 31, 1, 75000),
(18, 31, 1, 75000),
(19, 31, 1, 75000),
(20, 23, 1, 9),
(21, 25, 2, 200000);

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` int(11) NOT NULL,
  `kategori` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `kategori`) VALUES
(1, 'komik'),
(2, 'majalah');

-- --------------------------------------------------------

--
-- Table structure for table `kirim`
--

CREATE TABLE `kirim` (
  `id_kirim` int(11) NOT NULL,
  `id_pesan` varchar(225) NOT NULL,
  `tgl_kirim` date DEFAULT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kirim`
--

INSERT INTO `kirim` (`id_kirim`, `id_pesan`, `tgl_kirim`, `keterangan`) VALUES
(1, '11', '2023-10-23', 'dikirim'),
(2, '20', '2023-10-23', 'dikirim'),
(3, '21', '2023-10-23', 'dikirim');

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id_pelanggan` int(11) NOT NULL,
  `nama_pelanggan` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `kota` varchar(255) NOT NULL,
  `provinsi` enum('Nanggroe Aceh Darussalam','Sumatera Utara','Sumatera Selatan','Sumatera Barat','Bengkulu','Riau','Kepulauan Riau','Jambi','Lampung','Bangka Belitung','Kalimantan Barat','Kalimantan Timur','Kalimantan Selatan','Kalimantan Tengah','Kalimantan Utara','Banten','Dki Jakarata','Jawa Barat','Jawa Tengah','Daerah Istimewa Yogyakarta','Jawa Timur','Bali','Nusa Tenggara Timur','Nusa Tenggara Barat','Gorontalo','Sulawesi Barat','Sulawesi Tengah','Sulawesi Utara','Sulawesi Tenggara','Sulawesi Selatan','Maluku Utara','Maluku','Papua Barat','Papua','Papua Tengah','Papua Pegunungan','Papua Selatan','Papua Barat Daya') NOT NULL,
  `kdpos` int(11) NOT NULL,
  `tlpn` int(11) NOT NULL,
  `fax` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`id_pelanggan`, `nama_pelanggan`, `alamat`, `kota`, `provinsi`, `kdpos`, `tlpn`, `fax`, `email`, `password`) VALUES
(1, 'joel', 'lokomotif 14', 'bogor', 'Nanggroe Aceh Darussalam', 123, 8138219, 813138, 'joel@gmail.com', '123'),
(2, 'jo', 'jo', 'bogor', 'Nanggroe Aceh Darussalam', 0, 0, 2381, 'joelgamecoc@gmail.com', '123'),
(7, 'amos', '7', '7', 'Nanggroe Aceh Darussalam', 7, 7, 7, 'logintanparegislol@gmail.com', '1'),
(8, '1', 'am', '1', 'Daerah Istimewa Yogyakarta', 1, 1, 1, 'jo@gmail.com', '1');

-- --------------------------------------------------------

--
-- Table structure for table `penerbit`
--

CREATE TABLE `penerbit` (
  `id_penerbit` int(11) NOT NULL,
  `penerbit` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `penerbit`
--

INSERT INTO `penerbit` (`id_penerbit`, `penerbit`) VALUES
(1, 'Penerbit erlangga'),
(2, 'Penerbit Republika');

-- --------------------------------------------------------

--
-- Table structure for table `pengarang`
--

CREATE TABLE `pengarang` (
  `id_pengarang` int(11) NOT NULL,
  `pengarang` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pengarang`
--

INSERT INTO `pengarang` (`id_pengarang`, `pengarang`) VALUES
(1, 'Raditya Dika'),
(2, 'Dewi Lestari');

-- --------------------------------------------------------

--
-- Table structure for table `pesan`
--

CREATE TABLE `pesan` (
  `id_pesan` int(11) NOT NULL,
  `id_pelanggan` int(11) NOT NULL,
  `tgl_pesan` date NOT NULL,
  `status_pesan` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pesan`
--

INSERT INTO `pesan` (`id_pesan`, `id_pelanggan`, `tgl_pesan`, `status_pesan`) VALUES
(11, 1, '2023-10-19', 'Sudah Dikirim'),
(12, 1, '2023-10-19', 'belum bayar'),
(13, 1, '2023-10-20', 'belum bayar'),
(14, 1, '2023-10-20', 'belum bayar'),
(15, 1, '2023-10-20', 'belum bayar'),
(16, 1, '2023-10-20', 'belum bayar'),
(17, 1, '2023-10-23', 'belum bayar'),
(18, 1, '2023-10-23', 'belum bayar'),
(19, 1, '2023-10-23', 'belum bayar'),
(20, 1, '2023-10-03', 'Sudah Dikirim'),
(21, 1, '2023-10-23', 'Sudah Dikirim');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_users`);

--
-- Indexes for table `bayar`
--
ALTER TABLE `bayar`
  ADD PRIMARY KEY (`id_bayar`);

--
-- Indexes for table `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`id_buku`);

--
-- Indexes for table `dpesan`
--
ALTER TABLE `dpesan`
  ADD PRIMARY KEY (`id_pesan`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `kirim`
--
ALTER TABLE `kirim`
  ADD PRIMARY KEY (`id_kirim`);

--
-- Indexes for table `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indexes for table `penerbit`
--
ALTER TABLE `penerbit`
  ADD PRIMARY KEY (`id_penerbit`);

--
-- Indexes for table `pengarang`
--
ALTER TABLE `pengarang`
  ADD PRIMARY KEY (`id_pengarang`);

--
-- Indexes for table `pesan`
--
ALTER TABLE `pesan`
  ADD PRIMARY KEY (`id_pesan`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_users` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `bayar`
--
ALTER TABLE `bayar`
  MODIFY `id_bayar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `buku`
--
ALTER TABLE `buku`
  MODIFY `id_buku` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `dpesan`
--
ALTER TABLE `dpesan`
  MODIFY `id_pesan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `kirim`
--
ALTER TABLE `kirim`
  MODIFY `id_kirim` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `id_pelanggan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `penerbit`
--
ALTER TABLE `penerbit`
  MODIFY `id_penerbit` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pengarang`
--
ALTER TABLE `pengarang`
  MODIFY `id_pengarang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pesan`
--
ALTER TABLE `pesan`
  MODIFY `id_pesan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
